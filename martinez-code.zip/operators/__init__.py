"""
Init for operators
"""
from .operator_coin_api import ApiToMySql
from .operator_tweet_dump import TweetToMySql
from .operator_tweet_sentiment import TweetSentiment
